import 'package:flutter/material.dart';
import 'package:chargerhacks/Kishin Work.dart';
class CheckboxListTileApp extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Background(),
    );
  }
}


class Background extends StatefulWidget {


  @override
  _BackgroundState createState() => _BackgroundState();
}

class _BackgroundState extends State<Background> {
  bool checkboxValue1 = false;
  bool checkboxValue2 = false;
  bool checkboxValue3 = false;
  bool checkboxValue4 = false;
  bool checkboxValue5 = false;
  bool checkboxValue6 = false;
  bool checkboxValue7 = false;
  bool checkboxValue8 = false;
  bool checkboxValue9 = false;
  bool checkboxValue10 = false;
  bool checkboxValue11 = false;
  bool checkboxValue12 = false;
  bool checkboxValue13 = false;
  bool checkboxValue14 = false;
  bool checkboxValue15 = false;
  bool checkboxValue16 = false;
  bool checkboxValue17 = false;
  bool checkboxValue18 = false;
  bool checkboxValue19 = false;
  bool checkboxValue20 = false;
  bool checkboxValue21 = false;
  bool checkboxValue22 = false;
  bool checkboxValue23 = false;
  bool checkboxValue24 = false;
  bool checkboxValue25 = false;
  bool checkboxValue26 = false;
  bool checkboxValue27 = false;
  bool checkboxValue28 = false;
  bool checkboxValue29= false;
  bool checkboxValue30 = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisSize: MainAxisSize.max,
        verticalDirection: VerticalDirection.down,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
         Row(
            children: [
              Title(color: Colors.white, child: Text("Pill Papa",style: TextStyle(
                color: Colors.blueAccent, fontStyle: FontStyle.normal
              ),)),
            ]
      ),
          Text("Select Symptoms", style: TextStyle(
            fontStyle: FontStyle.italic,
          ),
          ),
          Container(
            height: 600,
            child: ListView(
              shrinkWrap: true,
              scrollDirection: Axis.vertical,
              itemExtent: 26,
              children: [
                CheckboxListTile(
                  value: checkboxValue1,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue1 = value;
                    });
                  },
                  title: const Text('Barking Cough'),
                  subtitle: const Text(''),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue2,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue2 = value;
                    });
                  },
                  title: const Text('Blackout'),
                  subtitle: const Text(''),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue3,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue3 = value;
                    });
                  },
                  title: const Text('Burning Sensation'),
                  subtitle: const Text(" "),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue4,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue4 = value;
                    });
                  },
                  title: const Text('Vascular Event'),
                  subtitle: const Text(''),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue5,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue5 = value;
                    });
                  },
                  title: const Text('Cyanosis'),
                  subtitle: const Text(''),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue6,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue6 = value;
                    });
                  },
                  title: const Text('Decreased Body Weight'),
                  subtitle: const Text(''),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue7,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue7 = value;
                    });
                  },
                  title: const Text('Difficulty Breathing'),
                  subtitle: const Text(''),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue8,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue8 = value;
                    });
                  },
                  title: const Text('Drowsiness'),
                  subtitle: const Text(''),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue9,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue9 = value;
                    });
                  },
                  title: const Text('Fatigability'),
                  subtitle: const Text(" "),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue10,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue10 = value;
                    });
                  },
                  title: const Text('Feeling Hopeless'),
                  subtitle: const Text(''),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue11,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue11 = value;
                    });
                  },
                  title: const Text('Fever'),
                  subtitle: const Text(''),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue12,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue12 = value;
                    });
                  },
                  title: const Text('Intoxication'),
                  subtitle: const Text(''),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue13,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue13 = value;
                    });
                  },
                  title: const Text('Lethargy'),
                  subtitle: const Text(''),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue14,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue14 = value;
                    });
                  },
                  title: const Text('Nausea'),
                  subtitle: const Text(''),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue15,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue15 = value;
                    });
                  },
                  title: const Text('Nightmare'),
                  subtitle: const Text(" "),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue16,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue16 = value;
                    });
                  },
                  title: const Text('Out of Breath'),
                  subtitle: const Text(''),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue17,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue17 = value;
                    });
                  },
                  title: const Text('Painful Swallowing'),
                  subtitle: const Text(''),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue18,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue18 = value;
                    });
                  },
                  title: const Text('Paresthesia'),
                  subtitle: const Text(''),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue19,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue19 = value;
                    });
                  },
                  title: const Text('Presence of q wave'),
                  subtitle: const Text(''),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue20,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue20 = value;
                    });
                  },
                  title: const Text('Spotaneous rupture of membranes'),
                  subtitle: const Text(''),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue21,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue21 = value;
                    });
                  },
                  title: const Text('Sweat'),
                  subtitle: const Text(" "),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue22,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue22 = value;
                    });
                  },
                  title: const Text('Tremor'),
                  subtitle: const Text(''),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue23,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue23 = value;
                    });
                  },
                  title: const Text('Unable to concentrate'),
                  subtitle: const Text(''),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue24,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue24 = value;
                    });
                  },
                  title: const Text('Unresponsiveness'),
                  subtitle: const Text(''),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue25,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue25 = value;
                    });
                  },
                  title: const Text('Vomiting'),
                  subtitle: const Text(''),
                ),
                const Divider(height: 0),
                CheckboxListTile(
                  value: checkboxValue26,
                  onChanged: (bool value) {
                    setState(() {
                      checkboxValue26 = value;
                    });
                  },
                  title: const Text('Label'),
                  subtitle: const Text(''),
                ),
              ],
            ),
          ),
          FloatingActionButton(onPressed: () => Navigator.push(context,
              MaterialPageRoute( builder: (context) => Kishin()))
          )
        ],
      ),
    );
  }
}
