import 'package:flutter/material.dart';

class Kishin extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Container(
      alignment: Alignment.center,
      child: Text("CardioVascular Ailment, Please see licensed cardiologist for indepth diagnosis", style: TextStyle(
        color: Colors.red, fontSize: 20,
      ),),
    );
  }
}
